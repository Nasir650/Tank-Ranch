/* Tank & Trench results pages: tracking hook.
   Nasir: paste the site's analytics snippet (e.g. GA4) below. Every page loads this file,
   so one edit covers all pages. The card's ref code is available as CODE. */
(function(){
  var s=document.currentScript; var CODE=s&&s.getAttribute('data-code');
  // Example for GA4 (uncomment once gtag is loaded on the page):
  // gtag('event','results_page_view',{ref_code:CODE});
  document.addEventListener('click',function(e){
    var a=e.target.closest&&e.target.closest('[data-track]'); if(!a) return;
    // gtag('event','results_'+a.getAttribute('data-track'),{ref_code:CODE});
  });
})();
TANK & TRENCH - POSTCARD RESULTS PAGES
======================================

WHAT THIS IS
Every postcard has a QR code that opens tankandtrench.com/r/<code>/ (example: tankandtrench.com/r/GA127-xd6t/).
This zip contains one static page per card: 3,590 folders, each with an index.html.
No database, no plugin, no code changes needed. Plain HTML + one CSS file + one JS file.

People who don't scan the QR can go to tankandtrench.com/check and type the code printed
on their card (e.g. GA127-XD6T). That page (the "check" folder) finds their /r/ page and
sends them there. It's one HTML file with no backend.

WHAT TO DO
1. Upload the "r" folder to the site's web root, so the files sit at:
     <web root>/r/GA127-xd6t/index.html
     <web root>/r/assets/style.css
     <web root>/r/assets/track.js
   On WordPress: upload via SFTP / file manager into public_html/r/ (same level as wp-content).
   WordPress's default .htaccess serves real folders/files directly, so these will load
   without touching WordPress.

   Also upload the "check" folder to the web root:
     <web root>/check/index.html
   If WordPress already has a page or post with the slug "check", rename or remove it
   (the folder wins on Apache, but it's confusing to keep both).
   NOTE: folder names are case-sensitive (GA127-xd6t). Keep them exactly as in the zip.

2. Test these URLs (they should load a styled page, on desktop and phone):
     https://tankandtrench.com/r/GA127-xd6t/
     https://tankandtrench.com/r/GA377-nzpp/
     https://tankandtrench.com/r/GA127-xd6t   (no trailing slash should also work)
     https://tankandtrench.com/check/  -> type  ga127 xd6t  -> should open GA127-xd6t's page
     https://tankandtrench.com/check/  -> type  GA127-XXXX  -> should say "couldn't find that code"
   The check page confirms a code exists by requesting /r/<code>/ and needs a real 404
   for codes that don't exist. WordPress returns a 404 for missing URLs by default, so
   this should just work. If a plugin redirects 404s to the homepage, exclude /r/.

3. Analytics: paste the site's analytics (e.g. GA4) into r/assets/track.js.
   Every page loads that one file, so one edit covers all 3,590 pages.
   Each page passes its card code (e.g. GA127) so scans can be tracked per card.
   Add the same analytics snippet to check/index.html if you want to count code lookups.
   The "Text Joe" and "Call" buttons have data-track attributes for click events.

IMPORTANT
- Every page has <meta name="robots" content="noindex,nofollow,noarchive">.
  Do NOT block /r/ in robots.txt (Google must be able to read the noindex tag),
  and do NOT add these pages to the sitemap or link to them from the site.
- Optional but good: add an "X-Robots-Tag: noindex" header for /r/ in the server
  or Cloudflare config.
- check/index.html is also noindex. Don't link to it from the site menu; it's for postcards only.
- r/index.html just redirects to the homepage, so /r/ itself shows nothing.
- If a caching/security plugin blocks static HTML folders, whitelist /r/.

FUTURE BATCHES
New mailings = new folders. Just copy the new folders into /r/. Nothing existing changes.
The /check page works for new batches automatically.

Questions: Joe (joe@tankandtrench.com)
